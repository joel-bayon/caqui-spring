package fr.rte_france.caqui.entity;

public enum Etat {CLOS, EN_COURS, EN_ATTENTE}