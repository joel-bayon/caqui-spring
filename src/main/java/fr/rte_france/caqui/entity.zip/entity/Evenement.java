package fr.rte_france.caqui.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;


/**
 * The persistent class for the EVENEMENT database table.
 * 
 */
@Entity
@NamedQuery(name="Evenement.findAll", query="SELECT e FROM Evenement e")
public class Evenement extends EcritureCahier implements Serializable {
	private static final long serialVersionUID = 1L;

	@ManyToOne
	//@JoinColumn(name="ID_OUVRAGE")
	private Ouvrage ouvrage;

	public Evenement() {}
	
	public Evenement(String libelle, Date debut,  Etat etat, Ouvrage ouvrage) {
		super(libelle, debut, etat);
		this.ouvrage = ouvrage;
	}

	public Ouvrage getOuvrage() {
		return this.ouvrage;
	}

	public void setOuvrage(Ouvrage ouvrage) {
		this.ouvrage = ouvrage;
	}
}